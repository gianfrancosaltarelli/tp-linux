#!/bin/bash

# Directorios a respaldar
DIRECTORIOS=("/root" "/etc" "/opt" "/var" "/www_dir" "/backup_dir")
FECHA=$(date +'%Y%m%d')

# Ruta del pendrive
PENDRIVE="/mnt/pendrive"

# Función para realizar el respaldo
hacer_respaldo() {
  DIR_ORIGEN=$1
  NOMBRE_ARCHIVO=$(basename "$DIR_ORIGEN")_bkp_${FECHA}.tar.gz
  echo "Comenzando respaldo de $DIR_ORIGEN..."

  sudo tar -czf "${PENDRIVE}/${NOMBRE_ARCHIVO}" "$DIR_ORIGEN"
  if [[ $? -eq 0 ]]; then
    echo "Respaldo de $DIR_ORIGEN completado correctamente."
  else
    echo "Error al realizar el respaldo de $DIR_ORIGEN."
  fi
}

# Recorremos todos los directorios y realizamos el respaldo
for DIR in "${DIRECTORIOS[@]}"; do
  hacer_respaldo "$DIR"
done

# Desmontamos el pendrive al finalizar
sudo umount "$PENDRIVE"
echo "El respaldo se completó. El pendrive ha sido desmontado."
