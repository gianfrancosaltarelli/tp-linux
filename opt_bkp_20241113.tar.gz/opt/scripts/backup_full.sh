
#!/bin/bash

# Función de ayuda
show_help() {
    echo "Uso: $0 <directorio_origen> <directorio_destino>"
    echo "Backup de un directorio especificado en el directorio de destino."
    echo "-h: Mostrar esta ayuda."
    echo "descripcion:"
    echo "Para mas informaicon,comuniquse con el area sistemas."
}

# Verifico si se pasó la opción de ayuda
if [[ "$1" == "-h" ]]; then
    show_help
    exit 0
fi

# Variables
FECHA=$(date +'%Y%m%d')      # Obtengo la fecha en formato YYYYMMDD
DIR_ORIGEN=$1                 # Directorio a respaldar, pasado como argumento
DIR_DESTINO=$2                # Directorio de destino, pasado como argumento

# Validación de que los argumentos no estén vacíos
if [ -z "$DIR_ORIGEN" ] || [ -z "$DIR_DESTINO" ]; then
    echo "Error: Se requieren dos argumentos."
    show_help
    exit 1
fi

# Valido que los sistemas de archivos origen y destino existan
if [ ! -d "$DIR_ORIGEN" ]; then
    echo "Error: El directorio origen '$DIR_ORIGEN' no existe o no está montado."
    exit 1
fi

if [ ! -d "$DIR_DESTINO" ]; then
    echo "Error: El directorio destino '$DIR_DESTINO' no existe o no está montado."
    exit 1
fi

# Obtengo el nombre del directorio origen para el nombre del archivo
NOMBRE_ORIGEN=$(basename "$DIR_ORIGEN")
NOMBRE_ARCHIVO="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

# Realizo el backup y guardo en el directorio de destino
tar -czf "${DIR_DESTINO}/${NOMBRE_ARCHIVO}" -C "$(dirname "$DIR_ORIGEN")" "$NOMBRE_ORIGEN"

# Compruebo el estado de la operación
if [ $? -eq 0 ]; then
    echo "Backup de '$DIR_ORIGEN' realizado exitosamente en '${DIR_DESTINO}/${NOMBRE_ARCHIVO}'."
else
    echo "Error al realizar el backup."
fi
